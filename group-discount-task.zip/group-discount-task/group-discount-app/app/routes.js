import { flatRoutes } from "@react-router/fs-routes";

export default flatRoutes();
