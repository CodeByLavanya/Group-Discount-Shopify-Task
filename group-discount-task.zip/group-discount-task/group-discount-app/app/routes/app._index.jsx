import { useEffect, useState } from "react";
import { InlineGrid, InlineStack } from "@shopify/polaris";
import "@shopify/polaris/build/esm/styles.css";
import styles from "./styles/StylesComponent.module.css";
import { useAppBridge } from "@shopify/app-bridge-react";

async function ensureCustomerDiscountGroupMetafieldDefinition() {
  try {
    const res = await fetch("shopify:admin/api/2025-04/graphql.json", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `
          mutation CreateCustomerDiscountGroupMetafieldDefinition(
            $definition: MetafieldDefinitionInput!
          ) {
            metafieldDefinitionCreate(definition: $definition) {
              createdDefinition {
                id
                name
              }
              userErrors {
                field
                message
                code
              }
            }
          }
        `,
        variables: {
          definition: {
            name: "Discount group",
            namespace: "discounts",
            key: "group",
            type: "single_line_text_field",
            ownerType: "CUSTOMER",
          },
        },
      }),
    });

    const json = await res.json();

    const userErrors = json?.data?.metafieldDefinitionCreate?.userErrors ?? [];

    if (userErrors.length > 0) {
      console.warn(
        "metafieldDefinitionCreate userErrors (may already exist):",
        userErrors,
      );
    } else {
      console.log(
        "Customer metafield definition 'Discount group' created:",
        json?.data?.metafieldDefinitionCreate?.createdDefinition,
      );
    }

    console.log("created successfully.....>>>>>>>>>>");
  } catch (error) {
    console.error(
      "Error creating customer discount group metafield definition:",
      error,
    );
  }
}

export default function DiscountConfiguration() {
  const [rows, setRows] = useState([
    { group: "tier1", discount: "30" },
    { group: "tier2", discount: "20" },
    { group: "tier3", discount: "30" },
    { group: "tier4", discount: "40" },
  ]);

  const [excludedProducts, setExcludedProducts] = useState([]);
  const [excludedProductIds, setExcludedProductIds] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const shopify = useAppBridge();

  useEffect(() => {
    ensureCustomerDiscountGroupMetafieldDefinition();
  }, []);

  useEffect(() => {
    async function loadDiscountConfig() {
      try {
        const res = await fetch("shopify:admin/api/2025-04/graphql.json", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            query: `
            query GetDiscountConfigMetafield {
              shop {
                id
                metafield(namespace: "discount_config", key: "tiers") {
                  type
                  value
                }
              }
            }
          `,
          }),
        });

        const json = await res.json();
        const metafield = json?.data?.shop?.metafield ?? null;

        if (!metafield || !metafield.value) {
          return;
        }

        const parsed = JSON.parse(metafield.value);

        if (Array.isArray(parsed.tiers)) {
          setRows(
            parsed.tiers.map((tier) => ({
              group: tier.group ?? "",
              discount:
                typeof tier.discount === "number"
                  ? String(tier.discount)
                  : (tier.discount ?? ""),
            })),
          );
        }

        if (Array.isArray(parsed.excludedProducts)) {
          setExcludedProductIds(parsed.excludedProducts);
        }
      } catch (error) {
        console.error("Error loading discount configuration metafield:", error);
      }
    }

    loadDiscountConfig();
  }, []);

  useEffect(() => {
    if (!allProducts.length || !excludedProductIds.length) return;

    const productsById = new Map(allProducts.map((p) => [p.id, p]));
    const restoredExcluded = excludedProductIds
      .map((id) => productsById.get(id))
      .filter(Boolean);

    setExcludedProducts(restoredExcluded);
  }, [allProducts, excludedProductIds]);

  useEffect(() => {
    async function fetchProducts() {
      try {
        setLoadingProducts(true);
        const res = await fetch("shopify:admin/api/2025-04/graphql.json", {
          method: "POST",
          body: JSON.stringify({
            query: `
              query ListProductsForExclusions {
                products(first: 120) {
                  nodes {
                    id
                    title
                    featuredImage {
                      url
                      altText
                    }
                  }
                }
              }
            `,
          }),
        });

        const json = await res.json();
        const nodes =
          (json &&
            json.data &&
            json.data.products &&
            json.data.products.nodes) ||
          [];
        setAllProducts(nodes);
      } catch (error) {
        console.error("Error loading products for exclusions", error);
      } finally {
        setLoadingProducts(false);
      }
    }

    fetchProducts();
  }, []);

  const addRow = () => {
    if (rows.length < 10) {
      setRows([...rows, { group: "", discount: "" }]);
    } else {
      shopify.toast.show("Limited to 10 tiers.");
    }
  };

  const removeRow = () => {
    if (rows.length > 1) {
      setRows(rows.slice(0, -1));
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);

    try {
      const tiers = rows.map((row) => ({
        group: row.group,
        discount: Number(row.discount || 0),
      }));

      const payload = {
        tiers,
        excludedProducts: excludedProducts.map((p) => p.id),
      };

      console.log("Submitting configuration", payload);

      const metafieldValue = JSON.stringify(payload);

      const shopRes = await fetch("shopify:admin/api/2025-04/graphql.json", {
        method: "POST",
        body: JSON.stringify({
          query: `
            query GetShopId {
              shop {
                id
              }
            }
          `,
        }),
      });

      const shopJson = await shopRes.json();
      const shopId =
        shopJson &&
        shopJson.data &&
        shopJson.data.shop &&
        shopJson.data.shop.id;

      if (!shopId) {
        console.error("Could not get shop id", shopJson);
        setSaving(false);
        return;
      }

      const metafieldsSetRes = await fetch(
        "shopify:admin/api/2025-04/graphql.json",
        {
          method: "POST",
          body: JSON.stringify({
            query: `
            mutation SaveDiscountConfigMetafield($metafields: [MetafieldsSetInput!]!) {
              metafieldsSet(metafields: $metafields) {
                metafields {
                  id
                  namespace
                  key
                  type
                  value
                }
                userErrors {
                  field
                  message
                }
              }
            }
          `,
            variables: {
              metafields: [
                {
                  ownerId: shopId,
                  namespace: "discount_config",
                  key: "tiers",
                  type: "json",
                  value: metafieldValue,
                },
              ],
            },
          }),
        },
      );

      const metafieldsSetJson = await metafieldsSetRes.json();
      const userErrors =
        (metafieldsSetJson &&
          metafieldsSetJson.data &&
          metafieldsSetJson.data.metafieldsSet &&
          metafieldsSetJson.data.metafieldsSet.userErrors) ||
        [];

      if (userErrors.length > 0) {
        console.error("Metafield save errors:", userErrors);
      } else {
        console.log(
          "Metafield saved:",
          metafieldsSetJson &&
            metafieldsSetJson.data &&
            metafieldsSetJson.data.metafieldsSet &&
            metafieldsSetJson.data.metafieldsSet.metafields,
        );
        console.log(">>> shop Id", shopId);
      }

      shopify.toast.show("Saved successfully!");
    } catch (error) {
      console.error("Error saving discount configuration metafield:", error);
    } finally {
      setSaving(false);
    }
  };
  const handleAddExcluded = (product) => {
    if (excludedProducts.some((p) => p.id === product.id)) return;
    setExcludedProducts([...excludedProducts, product]);
  };

  const handleRemoveExcluded = (productId) => {
    setExcludedProducts(excludedProducts.filter((p) => p.id !== productId));
  };

  const availableProducts = allProducts.filter(
    (product) => !excludedProducts.some((p) => p.id === product.id),
  );

  return (
    <form data-save-bar onSubmit={handleSubmit}>
      <s-page>
        <ui-title-bar title="Discount configuration" />

        <s-section>
          <div className={styles.card}>
            <s-stack gap="large">
              <InlineGrid columns="200px 120px" gap="400">
                <s-heading>Group</s-heading>
                <s-heading>Discount</s-heading>
              </InlineGrid>

              {rows.map((row, index) => (
                <InlineGrid
                  key={index}
                  columns="200px 120px auto"
                  gap="400"
                  align="center"
                >
                  <s-text-field
                    value={row.group}
                    onChange={(event) => {
                      const updated = [...rows];
                      updated[index].group = event.target.value || "";
                      setRows(updated);
                    }}
                    autocomplete="off"
                  />

                  <s-text-field
                    suffix="%"
                    value={row.discount}
                    onChange={(event) => {
                      const updated = [...rows];
                      updated[index].discount = event.target.value || "";
                      setRows(updated);
                    }}
                    autocomplete="off"
                  />

                  {index === rows.length - 1 && (
                    <InlineStack gap="300">
                      <s-button
                        icon="plus"
                        variant="primary"
                        onClick={addRow}
                      />
                      <s-button
                        icon="minus"
                        variant="secondary"
                        tone="critical"
                        disabled={rows.length === 1}
                        onClick={removeRow}
                      />
                    </InlineStack>
                  )}
                </InlineGrid>
              ))}

              <s-button variant="secondary" commandFor="modal">
                Exclude products
              </s-button>

              <s-text color="subdued">
                Selected products will be excluded from discount.
              </s-text>
              {excludedProducts.length > 0 && (
                <s-text color="subdued">
                  {excludedProducts.length} product
                  {excludedProducts.length === 1 ? "" : "s"} excluded.
                </s-text>
              )}

              <s-button variant="primary" type="submit" loading={saving}>
                Submit
              </s-button>
            </s-stack>
          </div>
        </s-section>
      </s-page>

      <s-modal id="modal" heading="Exclude products">
        <div className={styles.tabBtn}>
          <s-button
            variant={activeTab === "all" ? "primary" : "secondary"}
            type="button"
            onClick={() => setActiveTab("all")}
          >
            All products
          </s-button>
          <s-button
            variant={activeTab === "excluded" ? "primary" : "secondary"}
            type="button"
            onClick={() => setActiveTab("excluded")}
          >
            Excluded products
          </s-button>
        </div>

        {loadingProducts ? (
          <s-stack gap="base">
            <s-text>Loading products…</s-text>
          </s-stack>
        ) : (
          <div className={styles.modelflex}>
            {activeTab === "all" && (
              <s-box
                inlineSize="100%"
                padding="small-100"
                border="base"
                borderRadius="base"
                className={styles.leftside}
              >
                <s-heading>All products</s-heading>
                {availableProducts.length === 0 ? (
                  <s-text color="subdued">All products are excluded.</s-text>
                ) : (
                  <s-stack gap="small-100">
                    {availableProducts.map((product, index) => (
                      <s-box
                        key={index}
                        border="base"
                        borderRadius="base"
                        padding="small-100"
                      >
                        <s-stack
                          direction="inline"
                          alignItems="center"
                          justifyContent="space-between"
                          gap="base"
                        >
                          <div className={styles.pro_left}>
                            <s-thumbnail
                              size="small"
                              src={
                                product.featuredImage &&
                                product.featuredImage.url
                                  ? product.featuredImage.url
                                  : ""
                              }
                              alt={
                                (product.featuredImage &&
                                  product.featuredImage.altText) ||
                                product.title
                              }
                            />
                            <s-text>{product.title}</s-text>
                          </div>

                          <s-button
                            variant="secondary"
                            type="button"
                            onClick={() => handleAddExcluded(product)}
                          >
                            Exclude
                          </s-button>
                        </s-stack>
                      </s-box>
                    ))}
                  </s-stack>
                )}
              </s-box>
            )}

            {activeTab === "excluded" && (
              <s-box
                inlineSize="100%"
                padding="small-100"
                border="base"
                borderRadius="base"
                className={styles.rightside}
              >
                <s-heading>Excluded products</s-heading>
                {excludedProducts.length === 0 ? (
                  <s-text color="subdued">No products excluded yet.</s-text>
                ) : (
                  <s-stack gap="small-100">
                    {excludedProducts.map((product, index) => (
                      <s-box
                        key={index}
                        border="base"
                        borderRadius="base"
                        padding="small-100"
                      >
                        <s-stack
                          direction="inline"
                          alignItems="center"
                          justifyContent="space-between"
                          gap="base"
                        >
                          <div className={styles.pro_right}>
                            <s-thumbnail
                              size="small"
                              src={
                                product.featuredImage &&
                                product.featuredImage.url
                                  ? product.featuredImage.url
                                  : ""
                              }
                              alt={
                                (product.featuredImage &&
                                  product.featuredImage.altText) ||
                                product.title
                              }
                            />
                            <s-text>{product.title}</s-text>
                          </div>

                          <s-button
                            variant="secondary"
                            tone="critical"
                            type="button"
                            onClick={() => handleRemoveExcluded(product.id)}
                          >
                            Remove
                          </s-button>
                        </s-stack>
                      </s-box>
                    ))}
                  </s-stack>
                )}
              </s-box>
            )}
          </div>
        )}

        <s-button slot="secondary-actions" commandFor="modal" command="--hide">
          Close
        </s-button>
        <s-button
          slot="primary-action"
          variant="primary"
          commandFor="modal"
          command="--hide"
        >
          Save
        </s-button>
      </s-modal>
    </form>
  );
}

// Query => read the data (shop meta Fields)

// {
//   shop {
//     metafield(namespace: "discount_config", key: "tiers") {
//       id
//       namespace
//       key
//       value
//       type
//     }
//   }
// }

// Query => read the data (appInstallation metaField)

// query AppInstallationDiscountConfig(
//   $ownerId: ID!
//   $namespace: String!
//   $key: String!
// ) {
//   appInstallation(id: $ownerId) {
//     discountConfigTiers: metafield(namespace: $namespace, key: $key) {
//       id
//       type
//       value
//     }
//   }
// }

// Variable

// {
//   "ownerId": "gid://shopify/AppInstallation/639653413082", // different for each app Installation
//   "namespace": "discount_config",
//   "key": "tiers"
// }

//gid://shopify/MetafieldDefinition/150130196698
