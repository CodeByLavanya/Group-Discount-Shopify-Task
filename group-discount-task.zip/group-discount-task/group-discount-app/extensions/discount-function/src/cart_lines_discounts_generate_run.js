// @ts-check

import {
  DiscountClass,
  OrderDiscountSelectionStrategy,
} from "../generated/api";

/**
 * @typedef {import("../generated/api").Input} Input
 * @typedef {import("../generated/api").CartLinesDiscountsGenerateRunResult} CartLinesDiscountsGenerateRunResult
 * @typedef {import("../generated/api").OrderDiscountCandidate} OrderDiscountCandidate
 */

/**
 * @typedef {{ group: string; discount: number }} Tier
 * @typedef {{
 *   tiers: Tier[];
 *   excludedProducts?: string[];
 * }} Configuration
 */

/**
 * Entry point for cart.lines.discounts.generate.run
 *
 * @param {Input} input
 * @returns {CartLinesDiscountsGenerateRunResult}
 */
export function cartLinesDiscountsGenerateRun(input) {
  console.log("........>>>>>>>>>>>>>function Start");
  const discountClasses = input.discount.discountClasses || [];
  const hasOrderDiscountClass = discountClasses.includes(DiscountClass.Order);
  // console.log("........>>>>>>>>>>>>>function sett");
  // console.log("discountClasses:", discountClasses);

  if (!hasOrderDiscountClass) {
    return { operations: [] };
  }

  /** @type {Configuration} */
  const configuration =
    input.shop.metafield?.jsonValue ??
    /** @type {Configuration} */ ({
      tiers: [],
      excludedProducts: [],
    });

  for (const cart of input.cart.lines) {
    console.log(cart.quantity);
  }

  const customerTier =
    input.cart.buyerIdentity?.customer?.metafield?.value ?? null;

  const matchingTier =
    customerTier && Array.isArray(configuration.tiers)
      ? configuration.tiers.find((tier) => tier.group === customerTier)
      : undefined;

  console.log(">>>>>>>>>>>matching Tier", matchingTier);

  if (!matchingTier || !matchingTier.discount) {
    return { operations: [] };
  }

  const discountPercentage = matchingTier.discount;

  console.log(">>> customerTier:", customerTier);
  console.log(">>> configuration:", JSON.stringify(configuration));
  console.log(">>> matched tier, discount %:", discountPercentage);

  console.log(input.cart.cost.subtotalAmount.amount);

  /** @type {string[]} */
  const excludedCartLineIds = [];

  const excludedProducts = Array.isArray(configuration.excludedProducts)
    ? configuration.excludedProducts
    : [];

  for (const line of input.cart.lines) {
    if (line.merchandise.__typename !== "ProductVariant") continue;

    const productId = line.merchandise.product?.id;
    if (!productId) continue;

    if (excludedProducts.includes(productId)) {
      excludedCartLineIds.push(line.id);
    }
  }


  /** @type {OrderDiscountCandidate} */
  const candidate = {
    value: {
      percentage: {
        value: discountPercentage.toFixed(1),
      },
    },
    targets: [
      {
        orderSubtotal: {
          excludedCartLineIds,
        },
      },
    ],
    message: `${discountPercentage}% off your order`,
  };

  return {
    operations: [
      {
        orderDiscountsAdd: {
          candidates: [candidate],
          selectionStrategy: OrderDiscountSelectionStrategy.First,
        },
      },
    ],
  };
}

// "discountAutomaticAppCreate": {
//       "automaticAppDiscount": {
//         "discountId": "gid://shopify/DiscountAutomaticNode/1448142307546",
//         "title": "Group Discounts v4",
//         "status": "ACTIVE",
//         "appDiscountType": {
//           "appKey": "25e515edbd28a2472d54d87f4a85efed",
//           "functionId": "019b5a02-5f0e-7e7a-ad48-7dbdef97cd71"
//         }
//       },
//       "userErrors": []
//     }
//   },
